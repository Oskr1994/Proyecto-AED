package controlador;

import modelo.Cita;
import java.util.ArrayList;

public class GestorCita {

    private ArrayList<Cita> lista;
    private int contador;

    public GestorCita() {
        lista = new ArrayList<>();
        contador = 1;
    }

    public void agregar(String paciente, String medico,
                        String consultorio, String fecha,
                        String hora, String motivo) {

        Cita c = new Cita(contador++, paciente, medico,
                consultorio, fecha, hora, motivo, "Pendiente");

        lista.add(c);
    }

    public ArrayList<Cita> listar() {
        return lista;
    }

    public void cancelar(int numero) {
        for (Cita c : lista) {
            if (c.getNumero() == numero) {
                c.setEstado("Cancelada");
            }
        }
    }

    public void modificar(int numero, String paciente, String medico,
                          String consultorio, String fecha,
                          String hora, String motivo) {

        for (Cita c : lista) {
            if (c.getNumero() == numero) {
                c.setPaciente(paciente);
                c.setMedico(medico);
                c.setConsultorio(consultorio);
                c.setFecha(fecha);
                c.setHora(hora);
                c.setMotivo(motivo);
            }
        }
    }
}