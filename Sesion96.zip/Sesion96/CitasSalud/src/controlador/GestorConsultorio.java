package controlador;

import java.util.ArrayList;

import modelo.Consultorio;

public class GestorConsultorio {

    private ArrayList<Consultorio> lista;
    private int correlativo;

    public GestorConsultorio() {
        lista = new ArrayList<>();
        correlativo = 1;

    
        agregar("Consultorio 1");
        agregar("Consultorio 2");
    }

    public void agregar(String nombre) {
        Consultorio c = new Consultorio(correlativo++, nombre, 1);
        lista.add(c);
    }

    public void eliminar(int codigo) {
        for (Consultorio c : lista) {
            if (c.getCodigo() == codigo) {
                c.setEstado(0); 
                break;
            }
        }
    }

    public ArrayList<Consultorio> listar() {
        return lista;
    }
}