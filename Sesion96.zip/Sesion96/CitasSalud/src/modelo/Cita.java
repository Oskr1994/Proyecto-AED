package modelo;

public class Cita {

    private int numero;
    private String paciente;
    private String medico;
    private String consultorio;
    private String fecha;
    private String hora;
    private String motivo;
    private String estado;

    public Cita(int numero, String paciente, String medico,
                String consultorio, String fecha,
                String hora, String motivo, String estado) {

        this.numero = numero;
        this.paciente = paciente;
        this.medico = medico;
        this.consultorio = consultorio;
        this.fecha = fecha;
        this.hora = hora;
        this.motivo = motivo;
        this.estado = estado;
    }

    // GETTERS
    public int getNumero() { return numero; }
    public String getPaciente() { return paciente; }
    public String getMedico() { return medico; }
    public String getConsultorio() { return consultorio; }
    public String getFecha() { return fecha; }
    public String getHora() { return hora; }
    public String getMotivo() { return motivo; }
    public String getEstado() { return estado; }

    // SETTERS
    public void setPaciente(String paciente) { this.paciente = paciente; }
    public void setMedico(String medico) { this.medico = medico; }
    public void setConsultorio(String consultorio) { this.consultorio = consultorio; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    public void setHora(String hora) { this.hora = hora; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public void setEstado(String estado) { this.estado = estado; }
}