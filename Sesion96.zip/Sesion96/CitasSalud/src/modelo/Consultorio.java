package modelo;

public class Consultorio {
    private int codigo;
    private String nombre;
    private int estado;

    public Consultorio(int codigo, String nombre, int estado) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.estado = estado;
    }
}