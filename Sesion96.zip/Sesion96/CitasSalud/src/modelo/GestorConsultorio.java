package modelo;

import java.util.ArrayList;

public class GestorConsultorio {

    private ArrayList<Consultorio> lista;
    private int correlativo;

    public GestorConsultorio() {
        lista = new ArrayList<>();
        correlativo = 1;

        agregar("Pediatría");
        agregar("Cardiología");
        agregar("Traumatología");
    }

    public ArrayList<Consultorio> listar() {
        return lista;
    }

    public void agregar(String nombre) {
        Consultorio c = new Consultorio(correlativo++, nombre, 1);
        lista.add(c);
    }

    public void modificar(int codigo, String nuevoNombre) {
        for (Consultorio c : lista) {
            if (c.getCodigo() == codigo) {
                c.setNombre(nuevoNombre);
                break;
            }
        }
    }

    public void eliminar(int codigo) {
        for (Consultorio c : lista) {
            if (c.getCodigo() == codigo) {
                c.setEstado(0);
                break;
            }
        }
    }
}