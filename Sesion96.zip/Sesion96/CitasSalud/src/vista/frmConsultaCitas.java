package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class frmConsultaCitas extends JFrame {

    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JComboBox<String> cboPaciente;

    public frmConsultaCitas() {

        setTitle("Consulta de Citas");
        setSize(650, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());

        // =============================
        // PESTAÑAS
        // =============================
        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.addTab("Por Paciente", crearPanelPaciente());
        tabbedPane.addTab("Por Médico", new JPanel());
        tabbedPane.addTab("Por Fecha", new JPanel());
        tabbedPane.addTab("Por Consultorio", new JPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel crearPanelPaciente() {

        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel lblPaciente = new JLabel("Seleccione Paciente:");
        lblPaciente.setBounds(20, 20, 140, 25);
        panel.add(lblPaciente);

        cboPaciente = new JComboBox<>();
        cboPaciente.setBounds(160, 20, 200, 25);
        panel.add(cboPaciente);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(380, 20, 100, 25);
        panel.add(btnBuscar);

        // =============================
        // TABLA
        // =============================
        modeloTabla = new DefaultTableModel(
                new Object[]{"N° Cita", "Médico", "Fecha", "Hora", "Estado"}, 0
        );

        tabla = new JTable(modeloTabla);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(20, 70, 580, 180);
        panel.add(scroll);

        // Datos de prueba
        cargarPacientes();
        cargarDatosEjemplo();

        return panel;
    }

    private void cargarPacientes() {
        cboPaciente.addItem("Juan Perez");
        cboPaciente.addItem("Maria Lopez");
        cboPaciente.addItem("Carlos Ruiz");
    }

    private void cargarDatosEjemplo() {

        modeloTabla.addRow(new Object[]{
                1, "Dr. Garcia", "15/05/2024", "10:00", "Pendiente"
        });

        modeloTabla.addRow(new Object[]{
                3, "Dr. Torres", "20/05/2024", "09:00", "Atendida"
        });
    }
}