package vista;

import modelo.Consultorio;
import controlador.GestorConsultorio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class frmConsultorio extends JFrame {

    private JTextField txtNombre;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private GestorConsultorio gestor;

    public frmConsultorio() {

        gestor = new GestorConsultorio();

        setTitle("Mantenimiento de Consultorio");
        setSize(550, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        // LABEL
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(20, 20, 80, 25);
        add(lblNombre);

        // TEXTFIELD
        txtNombre = new JTextField();
        txtNombre.setBounds(100, 20, 200, 25);
        add(txtNombre);

        // BOTONES
        JButton btnAgregar = new JButton("Adicionar");
        btnAgregar.setBounds(20, 70, 120, 30);
        add(btnAgregar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(160, 70, 120, 30);
        add(btnEliminar);

        // TABLA
        modeloTabla = new DefaultTableModel(
                new Object[]{"Código", "Nombre", "Estado"}, 0);

        tabla = new JTable(modeloTabla);

        JScrollPane sp = new JScrollPane(tabla);
        sp.setBounds(20, 120, 490, 200);
        add(sp);

        // EVENTOS
        btnAgregar.addActionListener(e -> agregar());
        btnEliminar.addActionListener(e -> eliminar());

        listar();
    }

    private void agregar() {

        String nombre = txtNombre.getText().trim();

        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese nombre");
            return;
        }

        gestor.agregar(nombre);
        listar();
        txtNombre.setText("");
    }

    private void eliminar() {

        int fila = tabla.getSelectedRow();

        if (fila >= 0) {

            int codigo = (int) modeloTabla.getValueAt(fila, 0);
            gestor.eliminar(codigo);
            listar();

        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un registro");
        }
    }

    private void listar() {

        modeloTabla.setRowCount(0);

        for (Consultorio c : gestor.listar()) {

            modeloTabla.addRow(new Object[]{
                c.getCodigo(),
                c.getNombre(),
                c.getEstado() == 1 ? "Activo" : "Inactivo"
            });
        }
    }
}