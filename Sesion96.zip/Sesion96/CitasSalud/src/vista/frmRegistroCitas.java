package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import controlador.GestorCita;   // IMPORTANTE
import modelo.Cita;              // IMPORTANTE

public class frmRegistroCitas extends JFrame {

    private JComboBox<String> cboPaciente;
    private JComboBox<String> cboMedico;
    private JComboBox<String> cboConsultorio;
    private JComboBox<String> cboHora;
    private JComboBox<String> cboMotivo;
    private JTextField txtFecha;

    private DefaultTableModel modeloTabla;
    private JTable tabla;

    private GestorCita gestor;   // SOLO ESTA VARIABLE NUEVA

    public frmRegistroCitas() {

        gestor = new GestorCita();  // INICIALIZAMOS CONTROLADOR

        setTitle("Registro de Citas");
        setSize(750, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        // PACIENTE
        JLabel lblPaciente = new JLabel("Paciente:");
        lblPaciente.setBounds(20, 20, 80, 25);
        add(lblPaciente);

        cboPaciente = new JComboBox<>();
        cboPaciente.setEditable(true);
        cboPaciente.setBounds(100, 20, 200, 25);
        add(cboPaciente);

        // MEDICO
        JLabel lblMedico = new JLabel("Médico:");
        lblMedico.setBounds(350, 20, 80, 25);
        add(lblMedico);

        cboMedico = new JComboBox<>();
        cboMedico.setBounds(420, 20, 200, 25);
        add(cboMedico);

        // CONSULTORIO
        JLabel lblConsultorio = new JLabel("Consultorio:");
        lblConsultorio.setBounds(20, 60, 100, 25);
        add(lblConsultorio);

        cboConsultorio = new JComboBox<>();
        cboConsultorio.setBounds(100, 60, 200, 25);
        add(cboConsultorio);

        // FECHA
        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setBounds(350, 60, 80, 25);
        add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(420, 60, 200, 25);
        add(txtFecha);

        // HORA
        JLabel lblHora = new JLabel("Hora:");
        lblHora.setBounds(20, 100, 80, 25);
        add(lblHora);

        cboHora = new JComboBox<>();
        cboHora.setEditable(true);
        cboHora.setBounds(100, 100, 200, 25);
        add(cboHora);

        // MOTIVO
        JLabel lblMotivo = new JLabel("Motivo:");
        lblMotivo.setBounds(350, 100, 80, 25);
        add(lblMotivo);

        cboMotivo = new JComboBox<>();
        cboMotivo.setBounds(420, 100, 200, 25);
        add(cboMotivo);

        // BOTONES
        JButton btnAgregar = new JButton("Agregar Cita");
        btnAgregar.setBounds(80, 150, 150, 35);
        add(btnAgregar);

        JButton btnModificar = new JButton("Modificar");
        btnModificar.setBounds(260, 150, 150, 35);
        add(btnModificar);

        JButton btnCancelar = new JButton("Cancelar Cita");
        btnCancelar.setBounds(440, 150, 150, 35);
        add(btnCancelar);

        // TABLA
        modeloTabla = new DefaultTableModel(
                new Object[]{"N°", "Paciente", "Médico", "Consultorio", "Fecha", "Hora", "Motivo", "Estado"}, 0
        );

        tabla = new JTable(modeloTabla);
        JScrollPane sp = new JScrollPane(tabla);
        sp.setBounds(20, 210, 700, 170);
        add(sp);

        cargarDatos();

        // FECHA AUTOMÁTICA
        LocalDate hoy = LocalDate.now();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        txtFecha.setText(hoy.format(formato));

        // EVENTOS
        btnAgregar.addActionListener(e -> agregarCita());
        btnModificar.addActionListener(e -> modificarCita());
        btnCancelar.addActionListener(e -> cancelarCita());

        tabla.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                cargarDesdeTabla();
            }
        });
    }

    private void cargarDatos() {

        cboPaciente.addItem("Juan Perez");
        cboPaciente.addItem("Maria Lopez");

        cboMedico.addItem("Dr. Garcia");
        cboMedico.addItem("Dr. Ruiz");

        cboConsultorio.addItem("Consultorio 1");
        cboConsultorio.addItem("Consultorio 2");

        cboHora.addItem("09:00");
        cboHora.addItem("10:00");
        cboHora.addItem("11:30");

        cboMotivo.addItem("Consulta General");
        cboMotivo.addItem("Control");
        cboMotivo.addItem("Emergencia");
    }

    private void agregarCita() {

        gestor.agregar(
                cboPaciente.getSelectedItem().toString(),
                cboMedico.getSelectedItem().toString(),
                cboConsultorio.getSelectedItem().toString(),
                txtFecha.getText(),
                cboHora.getSelectedItem().toString(),
                cboMotivo.getSelectedItem().toString()
        );

        listar();
    }

    private void modificarCita() {

        int fila = tabla.getSelectedRow();

        if (fila >= 0) {

            int numero = (int) modeloTabla.getValueAt(fila, 0);

            gestor.modificar(numero,
                    cboPaciente.getSelectedItem().toString(),
                    cboMedico.getSelectedItem().toString(),
                    cboConsultorio.getSelectedItem().toString(),
                    txtFecha.getText(),
                    cboHora.getSelectedItem().toString(),
                    cboMotivo.getSelectedItem().toString());

            listar();
        }
    }

    private void cancelarCita() {

        int fila = tabla.getSelectedRow();

        if (fila >= 0) {

            int numero = (int) modeloTabla.getValueAt(fila, 0);
            gestor.cancelar(numero);

            listar();
        }
    }

    private void listar() {

        modeloTabla.setRowCount(0);

        for (Cita c : gestor.listar()) {

            modeloTabla.addRow(new Object[]{
                    c.getNumero(),
                    c.getPaciente(),
                    c.getMedico(),
                    c.getConsultorio(),
                    c.getFecha(),
                    c.getHora(),
                    c.getMotivo(),
                    c.getEstado()
            });
        }
    }

    private void cargarDesdeTabla() {

        int fila = tabla.getSelectedRow();

        cboPaciente.setSelectedItem(modeloTabla.getValueAt(fila, 1));
        cboMedico.setSelectedItem(modeloTabla.getValueAt(fila, 2));
        cboConsultorio.setSelectedItem(modeloTabla.getValueAt(fila, 3));
        txtFecha.setText(modeloTabla.getValueAt(fila, 4).toString());
        cboHora.setSelectedItem(modeloTabla.getValueAt(fila, 5));
        cboMotivo.setSelectedItem(modeloTabla.getValueAt(fila, 6));
    }
}